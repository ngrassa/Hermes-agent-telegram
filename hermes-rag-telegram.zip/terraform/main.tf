##############################################################
#  Hermes RAG Telegram Bot — Terraform (AWS Academy)
#  Région : us-east-1  |  Instance : t3.large
##############################################################

terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
  required_version = ">= 1.3.0"
}

provider "aws" {
  region = var.aws_region
}

##############################################################
# Data — AMI Amazon Linux 2023 (dernière version)
##############################################################
data "aws_ami" "amazon_linux" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }
  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

##############################################################
# Keypair SSH (génère une clé locale, upload la publique)
##############################################################
resource "tls_private_key" "bot_key" {
  algorithm = "RSA"
  rsa_bits  = 4096
}

resource "aws_key_pair" "bot_keypair" {
  key_name   = "${var.project_name}-keypair"
  public_key = tls_private_key.bot_key.public_key_openssh
}

# Sauvegarde de la clé privée localement
resource "local_file" "private_key" {
  content         = tls_private_key.bot_key.private_key_pem
  filename        = "${path.module}/../${var.project_name}-key.pem"
  file_permission = "0400"
}

##############################################################
# Security Group — SSH uniquement (le bot utilise le polling)
##############################################################
resource "aws_security_group" "bot_sg" {
  name        = "${var.project_name}-sg"
  description = "Security group pour le bot Hermes RAG"

  # SSH depuis ton IP uniquement (plus sécurisé qu'un 0.0.0.0/0)
  ingress {
    description = "SSH"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [var.allowed_ssh_cidr]
  }

  # Tout le trafic sortant autorisé (Groq API + Telegram polling)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name    = "${var.project_name}-sg"
    Project = var.project_name
  }
}

##############################################################
# IAM Role — accès S3 pour récupérer les docs
##############################################################
resource "aws_iam_role" "ec2_role" {
  name = "${var.project_name}-ec2-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
    }]
  })

  tags = { Project = var.project_name }
}

resource "aws_iam_role_policy" "s3_access" {
  name = "${var.project_name}-s3-policy"
  role = aws_iam_role.ec2_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["s3:GetObject", "s3:ListBucket"]
      Resource = [
        aws_s3_bucket.docs_bucket.arn,
        "${aws_s3_bucket.docs_bucket.arn}/*"
      ]
    }]
  })
}

resource "aws_iam_instance_profile" "ec2_profile" {
  name = "${var.project_name}-profile"
  role = aws_iam_role.ec2_role.name
}

##############################################################
# S3 Bucket — stockage des fichiers .txt / .md
##############################################################
resource "aws_s3_bucket" "docs_bucket" {
  bucket        = "${var.project_name}-docs-${random_id.suffix.hex}"
  force_destroy = true

  tags = { Project = var.project_name }
}

resource "aws_s3_bucket_versioning" "docs_versioning" {
  bucket = aws_s3_bucket.docs_bucket.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_public_access_block" "docs_block" {
  bucket                  = aws_s3_bucket.docs_bucket.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "random_id" "suffix" {
  byte_length = 4
}

##############################################################
# EC2 Instance t3.large + User Data (bootstrap automatique)
##############################################################
resource "aws_instance" "bot_server" {
  ami                    = data.aws_ami.amazon_linux.id
  instance_type          = "t3.large"
  key_name               = aws_key_pair.bot_keypair.key_name
  vpc_security_group_ids = [aws_security_group.bot_sg.id]
  iam_instance_profile   = aws_iam_instance_profile.ec2_profile.name

  # Taille disque augmentée pour les modèles et vecteurs
  root_block_device {
    volume_type           = "gp3"
    volume_size           = 20
    delete_on_termination = true
  }

  user_data = templatefile("${path.module}/user_data.sh.tpl", {
    s3_bucket       = aws_s3_bucket.docs_bucket.bucket
    aws_region      = var.aws_region
    telegram_token  = var.telegram_bot_token
    groq_api_key    = var.groq_api_key
    project_name    = var.project_name
  })

  tags = {
    Name    = "${var.project_name}-server"
    Project = var.project_name
  }
}
