# Guide d'utilisation — Exemple de base de connaissances

## Introduction

Ce fichier est un exemple de document que l'agent Hermes peut indexer et utiliser pour répondre aux questions.
Remplace ce fichier par tes propres documents `.txt` ou `.md`.

## Comment ajouter des documents

1. Place tes fichiers `.txt` ou `.md` dans le dossier `docs/`
2. Lance `./deploy.sh` pour les uploader sur S3 et les indexer
3. Ou, si le bot est déjà en cours, tape `/reload` dans Telegram

## Bonnes pratiques pour les documents RAG

- Préfère des fichiers bien structurés avec des titres clairs
- Un fichier par thème ou sujet est recommandé
- Les fichiers de moins de 50 ko sont traités le plus efficacement
- Utilise le Markdown pour une meilleure segmentation des chunks

## Exemples de cas d'usage

- Documentation technique interne
- Manuels de produits
- FAQ
- Cours et supports pédagogiques
- Procédures internes d'entreprise
